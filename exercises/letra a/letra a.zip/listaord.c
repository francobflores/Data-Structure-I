#include "listaord.h"

No* bucaChaveOrd(Lista* L, int valor)
{
    return NULL;
}
void insereOrd(Lista* L, int valor)
{

}

void excluiChaveOrd(Lista* L,int valor)
{
    
}